
### ros2-humble doku (useless and insufficient)
https://docs.ros.org/en/humble/Tutorials/Intermediate/Writing-an-Action-Server-Client/Py.html

### rclpy doku most of the time shit or incomplete
https://docs.ros.org/en/iron/p/rclpy/api/actions.html

### srclpy doku incredible ugly
https://docs.ros2.org/foxy/api/rclpy/api/actions.html

### random ass action doku auf anderer webseite
https://design.ros2.org/articles/actions.html

### ACTUAL FUCKING ROS DOKU (but still shit because to deep or not neccessary)
https://wiki.ros.org/actionlib/DetailedDescription#Simple_Action_Client

### Mit der Persönlichen vergewaltigung seiner Englisch kenntnisse und dem sehr großen persönlich benötigten Speicher in seinem Kopf kann man aus den vorausgehenden 5 Dokus insgesamt alle infos ziehen, aber spaß macht das sehr wenig

### example-git ros
https://github.com/ros2/examples/tree/foxy/rclpy/actions