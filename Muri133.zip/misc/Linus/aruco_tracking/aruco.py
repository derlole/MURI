import cv2 as cv
import numpy as np

# Marker size in mm
marker_size = 175

# Initialisieren der Kamera
img = cv.VideoCapture(0)
img.set(cv.CAP_PROP_FRAME_WIDTH, 2600)
img.set(cv.CAP_PROP_FRAME_HEIGHT, 1900)
# Define the ArUco dictionary
aruco_dict = cv.aruco.getPredefinedDictionary(cv.aruco.DICT_5X5_1000)
aruco_params = cv.aruco.DetectorParameters()
detector = cv.aruco.ArucoDetector(aruco_dict, aruco_params)

# Camera matrix and distortion coefficients
# Camera matrix and distortion coefficients
camera_matrix = np.array([
    [485.98256352079204, 0.0,           326.8156596599855],
    [0.0,                481.9114474146188, 231.52240485863123],
    [0.0,                0.0,           1.0]
], dtype=np.float32)

dist_coeffs = np.array([
    [-0.28206812200227427],
    [ 2.61448314076083],
    [ 0.020889912770543827],
    [ 0.017394594564323452],
    [-7.331368052181177]
], dtype=np.float32)


while True:
    # Lesen eines Frames
    success, frame = img.read()
    if not success:
        print("Fehler beim Lesen des Frames")
        break
    print(f'-----{frame.shape}')
    # Umwandeln des Frames in Graustufen
    frame_gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    
    # Erkennen des ArUco-Markers
    corners, ids, rejectedImgPoints = detector.detectMarkers(frame_gray)
    
    if ids is not None and len(corners) > 0:
        # Für jeden erkannten Marker
        for i in range(len(ids)):
            # Define 3D object points for the marker corners
            obj_points = np.array([
                [-marker_size/2,  marker_size/2, 0],
                [ marker_size/2,  marker_size/2, 0],
                [ marker_size/2, -marker_size/2, 0],
                [-marker_size/2, -marker_size/2, 0]
            ], dtype=np.float32)
            
            # Estimate pose using solvePnP
            success, rvec, tvec = cv.solvePnP(
                obj_points, 
                corners[i][0], 
                camera_matrix, 
                dist_coeffs,
                flags=cv.SOLVEPNP_IPPE_SQUARE
            )
            
            if success:
                # Ausgeben der Ergebnisse
                print(f"Marker ID {ids[i][0]}:")
                print(f"  Entfernung (tvec): {tvec.flatten()}")
                print(f"  Rotation (rvec): {rvec.flatten()}")
                
                # Optional: Draw axis on the marker
                cv.drawFrameAxes(frame, camera_matrix, dist_coeffs, rvec, tvec, marker_size/2)
        
        # Draw detected markers
        cv.aruco.drawDetectedMarkers(frame, corners, ids)
    
    # Anzeigen des Frames
    cv.imshow('Frame', frame)
    
    # Beenden des Programms
    if cv.waitKey(1) & 0xFF == ord('q'):
        break

# Schließen der Kamera
img.release()
cv.destroyAllWindows()