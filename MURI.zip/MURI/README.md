# MURI
M.U.R.I. (Mechanische Untergrund-Ratte für Inspektion)

Use in Version 1.1.0 only for drive along a pipe.

For Installation and Documentation read the .md files in docs/*






